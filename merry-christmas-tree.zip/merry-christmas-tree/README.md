# Merry Christmas Tree!

A Pen created on CodePen.io. Original URL: [https://codepen.io/chrisgannon/pen/dypvKvR](https://codepen.io/chrisgannon/pen/dypvKvR).

As always thanks for all the love and support over the year.

CodePen is still my favourite place in the world mainly because the community here is so friendly and encouraging.

Here's to a happy and prosperous new year! ❤🎉

If you like this animation [you can buy it!](https://gannon.tv/products/merry-christmas-tree)